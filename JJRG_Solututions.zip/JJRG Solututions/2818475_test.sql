-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: pdb42.your-hosting.net
-- Generation Time: Dec 04, 2019 at 03:22 PM
-- Server version: 5.7.20-log
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2818475_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `book_id` int(11) NOT NULL,
  `isbn` bigint(50) NOT NULL,
  `title` longtext NOT NULL,
  `edition` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `course` varchar(50) NOT NULL,
  `cost` float NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`book_id`, `isbn`, `title`, `edition`, `author`, `course`, `cost`) VALUES
(38, 9781890774943, 'Murach\'s C# 2015:Training+Reference', '6th', 'Anne Boehm', 'CPT-203', 32.71),
(41, 9780321776419, 'Programming in C', '5th', 'Stephen G. Kochan', 'CPT-200', 14.02),
(40, 9781890774967, 'Murach\'s SQL Server 2016 for Developers', '1st', 'Joel Murach', 'CPT-206', 46.58),
(39, 9781133526100, 'Blended HTML and CSS Fundamentals: Introductory', '3rd', 'Henry Bojack & Sharon Scollard', 'CPT-206', 15.32),
(62, 9780470257012, 'Beginning Microsoft SQL Server 2008 Programming', 'First', 'Robert Vieira', 'CPT-209', 75.49),
(61, 78972765, 'Java 2: Programmer and Developer Exams', 'Second', 'Jamie Jaworski', 'CPT-200', 49.99),
(63, 9781418836993, 'Wireless# Guide to Wireless Communications', 'Second', 'Jorge Olenewa, Mark Ciampa', 'CPT-203', 37.99),
(64, 9780136018216, 'Java: An Introduction to Problem Solving & Programming', 'Fifth', 'Walter Savitch, Frank M. Carrano', 'CPT-209', 42.99),
(65, 9780134611037, 'Introduction to Java Programming, Brief Version', '11th', 'Y. Daniel Liang', 'CPT-237', 156.03),
(66, 1943872074, 'Murach\'s Java Programming', '5th', 'Joel Murach', 'CPT-237', 59.57);

-- --------------------------------------------------------

--
-- Table structure for table `courses`
--

CREATE TABLE `courses` (
  `course_id` int(11) NOT NULL,
  `course` varchar(50) NOT NULL,
  `ins_name` varchar(50) NOT NULL,
  `ins_email` varchar(100) NOT NULL,
  `ins_phone` varchar(50) NOT NULL,
  `dir_name` varchar(50) NOT NULL,
  `dir_email` varchar(100) NOT NULL,
  `dir_phone` varchar(50) NOT NULL,
  `head_name` varchar(50) NOT NULL,
  `head_email` varchar(100) NOT NULL,
  `head_phone` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `courses`
--

INSERT INTO `courses` (`course_id`, `course`, `ins_name`, `ins_email`, `ins_phone`, `dir_name`, `dir_email`, `dir_phone`, `head_name`, `head_email`, `head_phone`) VALUES
(1, 'CPT-200', 'Adam Ricardo', 'adam@testingemail.com', '864-645-5486', 'Beau Sanders', 'beau@testingemail.com', '864-555-1234', 'Jessica Alba', 'jessica@testingemail.com', '864-789-1578'),
(2, 'CPT-206', 'Ryan Reynolds', 'ryan@testingemail.com', '864-779-1458', 'Beau Sanders', 'beau@testingemail.com', '864-555-1234', 'Jessica Alba', 'jessica@testingemail.com', '864-789-1578'),
(3, 'CPT-203', 'Will Smith', 'will@testingemail.com', '864-124-8347', 'Beau Sanders', 'beau@testingemail.com', '864-555-1234', 'Jessica Alba', 'jessica@testingemail.com', '864-789-1578'),
(8, 'CPT-237', 'Theodore Richards', 'richatar@my.gvltec.edu', '864-778-8648', 'Beau Sanders', 'beau@testingemail.com', '864-555-1234', 'Frank Reynolds', 'magnum@frank.rey', '694-206-9876'),
(7, 'CPT-209', 'Wendy Radar', 'radar@gvltec.edu', '864-456-7890', 'Beau Sanders', 'beau@testingemail.com', '864-555-1234', 'Jessica Alba', 'jessica@testingemail.com', '864-789-1578');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `isbn` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `author` varchar(100) NOT NULL,
  `publisher` varchar(100) NOT NULL,
  `course` varchar(50) NOT NULL,
  `cost` float NOT NULL,
  `semester` varchar(25) NOT NULL,
  `start_date` varchar(55) NOT NULL,
  `campus` varchar(100) NOT NULL,
  `ins_name` varchar(50) NOT NULL,
  `ins_phone` varchar(50) NOT NULL,
  `ins_email` varchar(100) NOT NULL,
  `dir_name` varchar(50) NOT NULL,
  `dir_phone` varchar(50) NOT NULL,
  `dir_email` varchar(100) NOT NULL,
  `head_name` varchar(50) NOT NULL,
  `head_phone` varchar(50) NOT NULL,
  `head_email` varchar(100) NOT NULL,
  `total` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `comments` varchar(1000) NOT NULL,
  `updated` text,
  `username` varchar(255) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `isbn`, `title`, `author`, `publisher`, `course`, `cost`, `semester`, `start_date`, `campus`, `ins_name`, `ins_phone`, `ins_email`, `dir_name`, `dir_phone`, `dir_email`, `head_name`, `head_phone`, `head_email`, `total`, `status`, `comments`, `updated`, `username`) VALUES
(10002, '9781133526100', 'Blended HTML and CSS Fundamentals: Introductory', 'Henry Bojack & Sharon Scollard', 'Cengage Learning', 'CPT-206', 15, 'Summer', '11-13-2019', 'Brashier', 'Ryan Reynolds', '864-779-1458', 'ryan@testingemail.com', 'Beau Sanders', '864-555-1234', 'beau@testingemail.com', 'Jessica Simpson', '864-789-1578', 'jessica@testingemail.com', 19, 'stocked on shelf', '', '16:54:11 11-12-2019', 'admin'),
(10003, '9781890774943', 'Murach\'s C# 2015:Training+Reference', 'Anne Boehm', 'Mike Murach & Associates', 'CPT-203', 32.71, 'Fall', '06-11-2020', 'Brashier', 'Will Smith', '864-124-8347', 'will@testingemail.com', 'Beau Sanders', '864-555-1234', 'beau@testingemail.com', 'Jessica Simpson', '864-789-1578', 'jessica@testingemail.com', 2, 'stocked on shelf', '', '00:03:01 11-13-2019', 'admin'),
(10004, '9781943872381', 'Murach\'s Php+Mysql', 'Joel Murach', 'Mike Murach & Associates', 'CPT-200', 46.98, 'Fall', '01-20-2020', 'Brashier', 'Adam Richards', '864-645-5486', 'adam@testingemail.com', 'Beau Sanders', '864-555-1234', 'beau@testingemail.com', 'Jessica Simpson', '864-789-1578', 'jessica@testingemail.com', 20, 'inventory received', '', '00:03:12 11-13-2019', 'admin'),
(10028, '9781890774967', 'Murach\'s SQL Server 2016 for Developers', 'Joel Murach', 'Mike Murach & Associates', 'CPT-206', 46.58, 'Fall', '02-23-2019', 'Benson', 'Ryan Reynolds', '864-779-1458', 'ryan@testingemail.com', 'Beau Sanders', '864-555-1234', 'beau@testingemail.com', 'Jessica Alba', '864-789-1578', 'jessica@testingemail.com', 13, 'order placed', '', '21:23:59 11-18-2019', 'instructor'),
(10021, '9781890774943', 'Murach\'s C# 2015:Training+Reference', 'Anne Boehm', 'Mike Murach & Associates', 'CPT-203', 32.71, 'Spring', '01-08-2020', 'Benson', 'Will Smith', '864-124-8347', 'will@testingemail.com', 'Beau Sanders', '864-555-1234', 'beau@testingemail.com', 'Jessica Simpson', '864-789-1578', 'jessica@testingemail.com', 2, 'order placed', '', '10:32:57 11-13-2019', 'instructor'),
(10040, '9781890774943', 'Murach\'s C# 2015:Training+Reference', 'Anne Boehm', 'Mike Murach & Associates', 'CPT-203', 32.71, 'Fall', '01-14-2020', 'Benson', 'Will Smith', '864-124-8347', 'will@testingemail.com', 'Beau Sanders', '864-555-1234', 'beau@testingemail.com', 'Jessica Alba', '864-789-1578', 'jessica@testingemail.com', 3, 'order placed', '', '18:41:39 11-26-2019', 'teach'),
(10020, '9781890774967', 'Murach\'s SQL Server 2016 for Developers', 'Joel Murach', 'Mike Murach & Associates', 'CPT-206', 46.58, 'Spring', '01-08-2020', 'Benson', 'Ryan Reynolds', '864-779-1458', 'ryan@testingemail.com', 'Beau Sanders', '864-555-1234', 'beau@testingemail.com', 'Jessica Simpson', '864-789-1578', 'jessica@testingemail.com', 4, 'order sent to publisher', '', '11:24:54 11-26-2019', 'head');

-- --------------------------------------------------------

--
-- Table structure for table `Publisher`
--

CREATE TABLE `Publisher` (
  `isbn` bigint(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `country` varchar(100) NOT NULL,
  `date` varchar(25) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Publisher`
--

INSERT INTO `Publisher` (`isbn`, `name`, `country`, `date`) VALUES
(9781890774943, 'Mike Murach & Associates', 'United States', '02-05-2016'),
(9781133526100, 'Cengage Learning', 'United States', '08-02-2012'),
(9781890774967, 'Mike Murach & Associates', 'United States', '06-30-2016'),
(9780321776419, 'Addison-Wesley Professional', 'United States', '08-28-2014'),
(78972765, 'Que Publishing', 'United States', '05-01-2002'),
(9780470257012, 'Wiley', 'United States', '01-01-2009'),
(9781418836993, 'Thomson Learning', 'United States', '07-15-2007'),
(9780136018216, 'Pearson Prentice Hall', 'United States', '01-01-2008'),
(9780134611037, 'Pearson', 'United States', '03-12-2017'),
(1943872074, 'Mike Murach & Associates', 'United States', '06-22-2017');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) NOT NULL,
  `created` text,
  `updated` text,
  `course` varchar(255) DEFAULT NULL,
  `email` varchar(30) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `role`, `created`, `updated`, `course`, `email`) VALUES
(4, 'admin@cpt275.beausanders.org', 'teamProjeck275', 'Administrator', '17:07:34 11-12-2019', '20:28:58 11-13-2019', '', 'admin@cpt275.beausanders.org'),
(9, 'departmenth', 'departmenth', 'Department_Head', '23:34:29 11-12-2019', '20:29:14 11-13-2019', '', 'departmenth@my.gvltec.edu'),
(10, 'instructor', 'instructor', 'Instructor', '00:08:28 11-13-2019', '11:28:07 11-26-2019', 'CPT-206', 'instructor@my.gvltec.edu'),
(11, 'employee', 'employee', 'Employee', '10:22:40 11-13-2019', '20:29:41 11-13-2019', '', 'employee@my.gvltec.edu'),
(21, 'gwilcox', 'gwilcox', 'Instructor', '14:39:29 11-26-2019', NULL, 'CPT-200', 'gee.wilcox517@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`book_id`),
  ADD KEY `ISBN` (`isbn`);

--
-- Indexes for table `courses`
--
ALTER TABLE `courses`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `Publisher`
--
ALTER TABLE `Publisher`
  ADD PRIMARY KEY (`isbn`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `book_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;
--
-- AUTO_INCREMENT for table `courses`
--
ALTER TABLE `courses`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10041;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
